package br.senai.core;

import br.senai.enumered.CategoriaProduto;
import br.senai.model.MaquinaVenda;
import br.senai.model.Produto;

public class Principal {
	
	public static void main(String[] args) {
		
		MaquinaVenda mv01 = new MaquinaVenda(0, "Shopping");
		MaquinaVenda mv02 = new MaquinaVenda(1, "Centro");
		
		Produto p1 = new Produto(1, "Coca-Cola", CategoriaProduto.BEBIDA, 0.75, 2.00);
		Produto p2 = new Produto(1, "Ruffles", CategoriaProduto.SALGADINHO, 1.20, 5.00);
		Produto p3 = new Produto(1, "Churros", CategoriaProduto.DOCE, 0.50, 2.50);
		
		mv01.adicionarProduto(p1);
		mv01.adicionarProduto(p2);
		mv01.adicionarProduto(p3);
		
		mv02.adicionarProduto(p1);
		mv02.adicionarProduto(p3);
		
		mv01.listarProdutos();
		mv02.listarProdutos();
		
		mv01.venderProduto(p1);
		mv01.venderProduto(p2);
		mv01.venderProduto(p3);
		mv01.venderProduto(p3);
		mv01.venderProduto(p3);
		mv01.venderProduto(p1);
		
		mv01.venderProduto(p3);
		mv01.venderProduto(p3);
		mv01.venderProduto(p1);
		
		mv01.resultadosFinanceiros();
		mv02.resultadosFinanceiros();
	}

}
