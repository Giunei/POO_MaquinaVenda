package br.senai.model;

import java.util.ArrayList;
import java.util.List;

public class MaquinaVenda {
	
	private Integer codigo;
	private String localidade;
	private List<Produto> produtosDisponiveis;
	private Double valorVendido;
	private Double valorDeLucro;
	
	public MaquinaVenda(Integer codigo, String localidade) {
		super();
		this.codigo = codigo;
		this.localidade = localidade;
		this.produtosDisponiveis = new ArrayList<Produto>();
		this.valorVendido = 0.0;
		this.valorDeLucro = 0.0;
	}

	public String getLocalidade() {
		return localidade;
	}

	public void setLocalidade(String localidade) {
		this.localidade = localidade;
	}

	public Integer getCodigo() {
		return codigo;
	}

	public List<Produto> getProdutosDisponiveis() {
		return produtosDisponiveis;
	}

	public Double getValorVendido() {
		return valorVendido;
	}

	public Double getValorDeLucro() {
		return valorDeLucro;
	}
	
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("M�quina de venda: "+codigo+"\n");
		sb.append("Localidade: "+this.localidade+"\n");
		sb.append("Quantida de produtos: "+this.produtosDisponiveis.size()+"\n");
		sb.append("Total de vendas R$: "+this.valorVendido+"\n");
		sb.append("Total de lucro R$: "+valorDeLucro);
		return super.toString();
	}
	
	public void adicionarProduto(Produto p) {
		this.produtosDisponiveis.add(p);
		System.out.println("Produto adicionado: "+p);
	}
	
	public void removerProduto(Produto p) {
		this.produtosDisponiveis.remove(p);
		System.out.println("Produto removido: "+p);
	}
	
	public void listarProdutos() {
		StringBuffer sb = new StringBuffer();
		for (Produto p : produtosDisponiveis) {
			sb.append("~~~~~~~~~~~~~~~~");
			sb.append("\n"+p);
		}
		System.out.println(sb.toString());
	}
	
	public void venderProduto(Produto p) {
		this.valorVendido += p.getValorVenda();
		this.valorDeLucro += p.calculaLucro();
		StringBuffer sb = new StringBuffer();
		sb.append("Venda efetuada:\n");
		sb.append(p);
		System.out.println(sb.toString());
	}
	
	public void resultadosFinanceiros() {
		StringBuffer sb = new StringBuffer();
		sb.append("Resultados Financeiros: \n");
		sb.append("C�digo: "+this.codigo+"\n");
		sb.append("Localidade: "+this.localidade+"\n");
		sb.append("Total Vendido R$: "+this.valorVendido+"\n");
		sb.append("Total de Lucro R$: "+this.valorVendido+"\n");
		System.out.println(sb.toString());
	}
	
}
