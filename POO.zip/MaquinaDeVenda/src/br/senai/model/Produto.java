package br.senai.model;

import br.senai.enumered.CategoriaProduto;

public class Produto {

	private Integer codigo;
	private String nome;
	private CategoriaProduto categoria;
	private Double valorCompra;
	private Double valorVenda;
	
	//Super
	
	public Produto (Integer codigo, String nome, CategoriaProduto categoria, Double valorCompra, Double valorVenda) {
		super();
		this.codigo = codigo;
		this.nome = nome;
		this.categoria = categoria;
		this.valorCompra = valorCompra;
		this.valorVenda = valorVenda;
	}

	//Gets e Sets
	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Integer getCodigo() {
		return codigo;
	}

	public CategoriaProduto getCategoria() {
		return categoria;
	}

	public Double getValorCompra() {
		return valorCompra;
	}

	public Double getValorVenda() {
		return valorVenda;
	}

	//Equals e hashCode
	
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codigo == null) ? 0 : codigo.hashCode());
		return result;
	}

	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Produto other = (Produto) obj;
		if (codigo == null) {
			if (other.codigo != null)
				return false;
		} else if (!codigo.equals(other.codigo))
			return false;
		return true;
	}
	
	//toString
	
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("Produto: "+this.nome+"\n");
		sb.append("Categoria: "+this.categoria+"\n");
		sb.append("R$ Compra: "+this.valorCompra+"\n");
		sb.append("R$ Venda: "+this.valorVenda+"\n");
		sb.append("R$ Lucro: "+calculaLucro()+"\n");
		return sb.toString();
	}
	
	public Double calculaLucro() {
		return this.valorCompra - this.valorVenda;
	}
	
}
