package br.senai.enumered;

public enum CategoriaProduto {
	
	BEBIDA,
	SALGADINHO,
	DOCE;

}
